let appRouter = function(app){

    app.get('/', function(req,res){
        res.status(200).send('Bem-Vindo ao nosso Web Service');
    });

    app.post('/', function(req,res){
        res.status(200).send('Respondendo ao método POST')
    })
    
}

module.exports = appRouter;